
struct ST_FOO
{

            unsigned int lServerID;
            unsigned int lObjID;
    char reserved[8];                   /*保留位*/
} ;
