#! /bin/sh

# struct size checker
# 检测yview 平台头文件中定义的结构体
# 在x86 与 x64平台下大小,布局是否一致
# by zhengsw 14:00 2016/10/17

cwd=`pwd`;									# 当前工作目录

# 要检查的头文件，按照依赖次序列出
cHeaderFileList="yvcommon_data_struct.h yvcommon_intercomm_msg_struct.h yvcommon_srv_dev_msg_struct.h yvcommon_msg_struct.h";

cCodeFile=$cwd/ssc_checkStructSize.c;			# 生成的C 代码文件名
compiledFile32=/tmp/ssc_checkStructSize_x86;	# 编译输出的 32位程序名
compiledFile64=/tmp/ssc_checkStructSize_x64;	# 编译输出的 64位程序名
exeOutFile32=/tmp/ssc_checkRes_32				# 32位程序检测结果
exeOutFile64=/tmp/ssc_checkRes_64				# 64位程序检测结果

# 生成头文件包含指令
function genCodeBefore()
{
	# 基本头文件
	cat >$1 <<EOF
#include <stdio.h>
#include <stddef.h>							/* for offsetof */

#if 1
#include "list.h"
#include "yvmcs.h"
#include "yvcommon.h"
#include "yvcommon_def.h"
#endif
EOF
	
	# 先生成头文件包含指令
	for i in $cHeaderFileList
	do
		echo "#include \"$i\""
	done >> $1

	# 生成 main头
	cat >>$1 <<EOF
int main(int argc, char * argv[])
{
EOF
}

# 生成 awk 脚本
function genAwkScript
{
	cat <<"EOF"					# 不让 shell 将文本中内容自以为是地展开
#! /bin/awk

BEGIN{
	crtNormalSt="";				# 当前处理的常规结构体名字
	
	bInAnonStDef=0;				# 是否处理匿名结构体定义中
	crtAnonTypedefSt="";		# 当前遇到的匿名结构体名字
	arrASTMI[1, "mem"]="NONE";	# arr Anonymous Struct Member Info,二维数组
	astFilename="";				# 当前匿名结构体定义所在文件
	memIdx=1;					# 当前处理的匿名结构体的成员索引
}

# 获取路径中的最后一个分量
function basename(strPath)
{
	n=split(strPath, arr, "/");
	return arr[n];
}

# 提取出一tag 行中记录的行号
function getLineNo(strLine)
{
	match(strLine, /line:([0-9]+)/, arr);
	return arr[1];
}

# 匹配到结构体定义
/;"[ \t]+s/{					
	crtNormalSt=$1;				# 更新当前结构体
	lineNO=getLineNo($0);		# 获取其中的行号
	
	printf("printf(\"sizeof struct %s: %zu def at %s:%s\\n\", sizeof(struct %s));\n", \
		   $1, basename($2), lineNO, $1);
}

# 匹配到结构体成员定义
/;"[ \t]+m/{					
	lineNO=getLineNo($0);		# 获取其中的等号
	filename=basename($2);

	# 获取当前所属的结构体,提取到的部分不能有空格,tab,:
	match($0, /struct:([^ \t:]+)/, arr);
	ownSt=arr[1];
	
	if(ownSt == crtNormalSt)
	{   # 该成员属于一个常规结构体定义
		printf("printf(\"\toffsetof %s.%s: %zu def at %s:%s\\n\", offsetof(struct %s, %s));\n", \
			   crtNormalSt, $1, filename, lineNO, crtNormalSt, $1);
	}
	else 
	{	# 该成员属于一个匿名结构体定义
		if(bInAnonStDef == 0)
		{	# 匿名结构体的第一个成员
			bInAnonStDef=1;
			crtAnonTypedefSt="";		# typedef 在此处未知，先清空它
			memIdx=1;
			astFilename=filename;
		}

		# 保存下成员信息
		arrASTMI[memIdx, "mem"]=$1;
		arrASTMI[memIdx++, "lineNO"]=lineNO;
	}
}

# 匹配到匿名结构体定义结尾，则匿名结构体定义结束
# 跳过结构体内部的 union，并且这不是一个 typedef
/typeref:struct:__anon/ && $0!~/union:/ && $0!~/;"[ \t]+m/{
	bInAnonStDef=0;				# 不再在匿名结构体定义中
	crtAnonTypedefSt=$1;		# 拿到了 typedef 名字
	lineNO=getLineNo($0);		# 获取其中的行号

	# 先输出结构体大小
	printf("printf(\"sizeof %s: %zu def at %s:%s\\n\", sizeof(%s));\n", $1, astFilename, lineNO, $1)
	
	# 依次输出各个成员的 offset
	for(i=1; i<memIdx; i++)
	{
		printf("printf(\"\toffsetof %s.%s: %zu def at %s:%s\\n\", offsetof(%s, %s));\n", \
			   crtAnonTypedefSt, arrASTMI[i, "mem"], astFilename, arrASTMI[i, "lineNO"], crtAnonTypedefSt, arrASTMI[i, "mem"]);
	}
}
EOF
}

# 生成封闭大括号，结束C 代码生成
function genCodePost()
{
	echo "}">>$1
}

# 编译 C 代码
function compile()
{
	gcc $1 -m32 -o $2;
	gcc $1 -m64 -o $3;
}

# 运行 C 代码生成的可执行文件
function runCheckExe()
{
	$1>$2;
	$3>$4;
}

# diff 两个程序的输出内容
function diffStructLayout()
{	# 定制 diff 的输出格式
	diff $1 $2 --old-line-format="in X86: %L" --new-line-format="in X64: %L" --unchanged-line-format="";
}

# 清理一些临时文件
function cleanfiles()
{
	rm $cwd/tags;
	rm $cCodeFile
}

# 扫描相关头文件生成 tags --> tags
# 显示结构体及其成员以及typedef，不进行按名称排序，打印定义所在行号
ctags --c-kinds=mst --sort=no --fields=+n $cwd/$cHeaderFileList;

# 生成 printSize 之前的代码 --> $cCodeFile
# 包括 include 语句和 main 函数部分
genCodeBefore $cCodeFile;

# 根据 tags 生成 C 代码文件，--> $cCodeFile
# awk 的输入脚本由genAwkScript 函数生成
genAwkScript | awk -f - tags >> $cCodeFile;

# 生成最后的收尾代码，"}", --> $cCodeFile
genCodePost $cCodeFile;

# 编译输出两种架构的可执行文件 --> $compiledFile32, $compiledFile64
compile $cCodeFile $compiledFile32 $compiledFile64;

# 执行编译输出的程序，保存各自的输出到文件中 --> $exeOutFile32 $exeOutFile64;
runCheckExe $compiledFile32 $exeOutFile32 $compiledFile64 $exeOutFile64;

# 对两种架构可执行文件的输出进行 diff --> stout
diffStructLayout $exeOutFile32 $exeOutFile64;

# 清理
# cleanfiles;
