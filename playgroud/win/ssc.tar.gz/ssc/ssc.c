#include <stdio.h>
#include <stddef.h>

/*数据描述结构定义*/
typedef struct
{
	int x;
    union
    {
        struct /*视频私有数据描述*/
        {
            short lCodec;    /*编码制式*/
            short lDpi;      /*分辨率*/
            int lHeight;     /*高度*/
            int lWidth;      /*宽度*/
            char reserve[4]; /*保留位*/
        };
        struct /*音频私有数据描述*/
        {
            unsigned char lSample;     /*采样频率*/
            unsigned char lBitwidth;   /*量化位数*/
            unsigned char lChannelNum; /*声道*/
            unsigned char lCodec;      /*编码制式*/
            char reserve[12];          /*保留位*/
        }AudioPriv;
        struct /*通用数据私有数据描述*/
        {
            char reserve[16];
        }CommonPriv;
    }U;
} ST_DataDesc;

int main()
{
	printf("%d\n", offsetof(ST_DataDesc, x));
	printf("%d\n", offsetof(ST_DataDesc, U));
	printf("%d\n", offsetof(ST_DataDesc, U.lCodec));
	printf("%d\n", offsetof(ST_DataDesc, U.AudioPriv.lSample));
}
